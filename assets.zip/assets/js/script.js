/**
 * bibliotecas base de aplciação para funcionamento do script
 */
/* biblioteca base */
$(document).ready(function () {
	$('[data-bs-toggle="popover"]').popover();
	/* remove botao direito do id */
	const div = document.getElementById("body");
	// div.addEventListener("contextmenu", (e) => { e.preventDefault() });
	/* fecha remove botao direito do id */
	disparos();
});
/* fecha biblioteca base */
/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * função para validar atributos e atualizar @disparos
 * $atributos -> array
 */
/* disparos */
//executa funções de att de valor por atributos
function disparos() {
	//declara as atributos/sessões para que percorra os disparos em todas as camadas e calcule os valores
	const atributos = [
		"fisico",
		"mental",
		"social",
	];
	for (let i = 0; i < atributos.length; i++) {
		let categoria = 'categoria_' + atributos[i].toString();
		let atributo = 'atributo_' + atributos[i].toString();
		qtdAtributos(categoria, atributo);
	}
	validaBtn();
}
/* fecha disparos */
/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * bibliotecas de:
 * monta estrutura de elementos para serem adicionados @addElement
 * $parentId ->
 * $elementTag ->
 * $elementId -> 
 * $html ->
 * adição de input @addField
 * $id ->
 * $valor ->
 * remoção de input @removeField
 * $elementId ->
 * $id ->
 * $valor ->
 * quantificar itens @qtdItens
 * $id ->
 * quantificar Atributos @qtdAtributos
 * $id -> string
 * $el -> string
 */
/* add item */
let fieldId = 0;//declaração de field para funcionar add e remove 
//gera elemento
function addElement(parentId, elementTag, elementId, html) {
	let id = document.getElementById(parentId);//identifica elemento
	let newElement = document.createElement(elementTag); //cria novo elemento
	newElement.setAttribute('id', elementId); //add id
	newElement.setAttribute('class', 'col-auto px-1');//add classe
	newElement.innerHTML = html;//gera dom
	id.appendChild(newElement);//aplica depois do id

}
//add input
function addField(id, valor) {
	fieldId++;
	let html = '<input class="form-check-input ' + id + '" type="checkbox" id="inlineCheckbox" value="option" checked onclick="removeField(' + fieldId + ',\'' + id + '\', ' + valor + ');">';
	addElement(id, 'div', 'field-' + fieldId, html);
	qtdItens(id);//aciona função
	carteira('D', valor);//aciona função //D = decremento / I = incremento
	disparos();//aciona função
}
//remove input
function removeField(elementId, id, valor) {
	let fieldId = "field-" + elementId;
	let element = document.getElementById(fieldId);
	element.parentElement.removeChild(element);
	qtdItens(id);//aciona função
	carteira('I', valor);//aciona função //D = decremento / I = incremento
	disparos();//aciona função
}
/* fecha add item */

/* conta quantidade itens */
//aplica no item a quantidade de pontos
function qtdItens(id) {
	const inputs = document.querySelectorAll("." + id);
	document.getElementById("categoria_" + id).innerHTML = inputs.length;
};
/* fecha conta quantidade itens */

/* soma quantidade atributos */
//aplica no titulo a quantidade de pontos dos itens que tem o atributo
function qtdAtributos(id, el) {
	let total = 0;
	$.each($('[id^=' + id + ']'), function (index, value) {
		total = total + parseInt($(value).text());
	});
	document.getElementById(el).innerHTML = total;
};
/* fecha soma quantidade atributos */

/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * biblioteca de regras
 * Decrementa ou Incrementa pontos na carteira de crédito ou gasto @carteira 
 * $tipo -> string = //D = decremento / I = incremento
 * $valor -> string = quantidade de pontos
 * valida se carteira de crédito tem valor suficiente para exibir ou ocultar btn @validaBtn
 */

/** REGRAS **/
//id="titulo_carteira" - ponto itens
function carteira(tipo, valor) {//tipo D = decremento / I = incremento //valor 
	//carteira_credito
	const carteira_credito = parseInt(document.getElementById('carteira_credito').innerText);
	const operacao_credito = (tipo === 'D' ? carteira_credito - valor : carteira_credito + valor)
	document.getElementById('carteira_credito').innerHTML = operacao_credito;
	const carteira_credito_att = parseInt(document.getElementById('carteira_credito').innerText);//pega valor att da carteira
	//carteira_gasto	
	const carteira_gasto = parseInt(document.getElementById('carteira_gasto').innerText);
	const operacao_gasto = (tipo === 'D' ? carteira_gasto + valor : carteira_gasto - valor)//inverte a operação
	document.getElementById('carteira_gasto').innerHTML = operacao_gasto;
	const carteira_gasto_att = parseInt(document.getElementById('carteira_gasto').innerText);//pega valor att da carteira
};

/* validaBtn */
function validaBtn() {
	//each percorre o fonte procurando o id
	let id = 'add_items';
	let tag = '';
	let carteira_credito = parseInt(document.getElementById('carteira_credito').innerText);//converte para inteiro //resgata elemento // transforma em texto
	$.each($('[id=' + id + ']'), function (index, value) {
		tag = value
			.childNodes[0]//busca nó filho
			.onclick//acessa função onclick
			.toString()//converte para string
			.replace('function onclick(event) {', '')//remove caracteres
			.replace('addField(', '')
			.replace('}', '')
			.replace("'", '')
			.replace("'", '')
			.replace(');', '')
			.split(',')
			;
		// let categoria = tag[0].toString();//converte para string
		let valor = parseInt(tag[1]);//converte para inteiro
		let ponto = parseInt(valor);//converte para inteiro
		value.style.display = (carteira_credito >= ponto) ? 'block' : 'none';//se carteira_credito maior que pontos botão visivel, contrário desativa
		//console.log(tag[0]);
	});
}
/* fecha validaBtn */

/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * importe json modal
 * efetua a leitura de um json e lista dentro de tags
 */
// var requestURL = "http://localhost/testes/dark/assets/json/json.json";
// var section = document.querySelector("section");
// var request = new XMLHttpRequest();
// request.open("GET", requestURL);
// request.responseType = "json";
// request.send();
// request.onload = function () {
// 	var items = request.response;
// 	showItems(items);
// };

// function showItems(jsonObj) {
// 	var heroes = jsonObj["items"];

// 	for (var i = 0; i < heroes.length; i++) {
// 		var myArticle = document.createElement("article");
// 		var myH2 = document.createElement("h2");
// 		var myPara1 = document.createElement("p");
// 		var myPara2 = document.createElement("p");
// 		var myPara3 = document.createElement("p");
// 		var myList = document.createElement("ul");

// 		myH2.textContent = heroes[i].nome;
// 		myPara1.textContent = "Nome: " + heroes[i].tipo;
// 		myPara2.textContent = "Custo: " + heroes[i].custo;
// 		myPara3.textContent = "Tipo:";

// 		var desc = heroes[i].descricao;
// 		for (var j = 0; j < desc.length; j++) {
// 			var listItem = document.createElement("li");
// 			listItem.textContent = desc[j];
// 			myList.appendChild(listItem);
// 		}

// 		myArticle.appendChild(myH2);
// 		myArticle.appendChild(myPara1);
// 		myArticle.appendChild(myPara2);
// 		myArticle.appendChild(myPara3);
// 		myArticle.appendChild(myList);

// 		section.appendChild(myArticle);
// 	}
// }
/**
 * importJson
 */
/**
 * executa json importando listagem
 * el -> string //'items'
 * tag -> string //'importJson'
 * arq -> string //'masc'
 */
function importJson(el, tag, arq) {
	let requestURL = `http://localhost/testes/dark/assets/json/${arq}.json`;
	let section = document.getElementById(tag);
	let request = new XMLHttpRequest();
	request.open("GET", requestURL);
	request.responseType = "json";
	request.send();
	request.onload = function () {
		let items = request.response;
		showItems(items);
	};

	function showItems(jsonObj) {
		let old = document.getElementById("blocoJson");
		old.remove();
		let data = jsonObj[el];
		let bloco = document.createElement("div");
		bloco.setAttribute('id', 'blocoJson');
		section.appendChild(bloco);
		for (let i = 0; i < data.length; i++) {
			let myH2 = document.createElement("div");
			myH2.textContent = data[i].nome;
			bloco.appendChild(myH2);
		}
	}
}
/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * bibliotecas do script tema
 * 
 * /retorna o tipo de tema light/dark
 */
const setTheme = () => {
	const currentTheme = localStorage.getItem('theme');
	// Default to light theme
	if (!currentTheme) {
		localStorage.setItem('theme', 'bg-dark-theme');
		document.documentElement.dataset.theme = 'bg-dark-theme';
		return;
	}
	document.documentElement.dataset.theme = currentTheme;
}

// Set theme on page load
setTheme();
const transition = () => {
	document.documentElement.classList.add('transition');
	setTimeout(() => {
		document.documentElement.classList.remove('transition');
	}, 1000)
}
// Handle theme toggle
const themeToggleBtn = document.querySelector('.js-toggle-theme');
themeToggleBtn.addEventListener('click', () => {
	const { theme } = document.documentElement.dataset;
	const themeTo = theme === 'bg-light-theme' ? 'bg-dark-theme' : 'bg-light-theme';
	const themeLabel = `Activate ${theme} mode`;
	document.documentElement.dataset.theme = themeTo;
	localStorage.setItem('theme', themeTo);
	themeToggleBtn.setAttribute('aria-label', themeLabel);
	themeToggleBtn.setAttribute('title', themeLabel);
	transition();
});
/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * bibliotecas do JKP
 * simula um jpk rápido
 * 
 *  user  -> string //qual pô enviado
 *  id  -> int //se for 3 pode usar bomba, abaixo apenas PPT
 */
function jkp(user, id) {
	let adm = '';
	let resultado = '';
	adm = Math.floor(Math.random() * id);
	switch (adm) {
		case 0: adm = 'Pedra'; break;
		case 1: adm = 'Papel'; break;
		case 2: adm = 'Tesoura'; break;
		case 3: adm = 'Bomba'; break;
		default:
			console.log(`Ocorreu um erro, contacte o adm.`);
	}

	if (user === adm) {
		resultado = '<i class="bi bi-emoji-neutral"></i> <small>Empate!</small>';
	} else if (user === 'Bomba' && adm === 'Pedra') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Pedra ganhou!</small>';
	} else if (user === 'Bomba' && adm === 'Papel') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Papel ganhou!</small>';
	} else if (user === 'Pedra' && adm === 'Tesoura') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Pedra ganhou!</small>';
	} else if (user === 'Papel' && adm === 'Bomba') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Papel ganhou!</small>';
	} else if (user === 'Papel' && adm === 'Pedra') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Papel ganhou!</small>';
	} else if (user === 'Tesoura' && adm === 'Bomba') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Tesoura ganhou!</small>';
	} else if (user === 'Tesoura' && adm === 'Pedra') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Pedra ganhou!</small>';
	} else if (user === 'Tesoura' && adm === 'Papel') {
		resultado = '<i class="bi bi-emoji-smile"></i> <small>Tesoura ganhou!</small>';
	} else if (user === 'Bomba' && adm === 'Tesoura') {
		resultado = '<i class="bi bi-emoji-dizzy-fill"></i> <small>Bomba ganhou!</small>';
	} else if (user === 'Pedra' && adm === 'Bomba') {
		resultado = '<i class="bi bi-emoji-dizzy-fill"></i> <small>Pedra ganhou!</small>';
	} else if (user === 'Pedra' && adm === 'Papel') {
		resultado = '<i class="bi bi-emoji-dizzy-fill"></i> <small>Papel ganhou!</small>';
	} else if (user === 'Papel' && adm === 'Tesoura') {
		resultado = '<i class="bi bi-emoji-dizzy-fill"></i> <small>Tesoura ganhou!</small>';
	} else {
		resultado = '<i class="bi bi-question-circle"></i> <small>Erro, favor contactar o adm!</small>';
	}

	document.getElementById('jkp_response').innerHTML = `
	<div class="position-fixed bottom-0 end-0 p-3">
		<div class="alert alert-info alert-dismissible fade show m-0">
			<p class="m-0">${resultado} Adversário usou: ${adm} e Você usou: ${user}</p>
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
	</div>
	`;
}
/**
 * ///////////////////////////////////////////////////////////
 */

/**
 * DOC nomenclaruta
 *	Atributo
 *		> Categoria
 *			> Trait
 */